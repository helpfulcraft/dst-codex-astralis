
AddTaskSet("lavaarena_taskset", {
    name = STRINGS.UI.CUSTOMIZATIONSCREEN.TASKSETNAMES.LAVA_ARENA,
    location = "lavaarena",
    tasks = {
        "LavaArenaTask",
    },
    valid_start_tasks = {
        "LavaArenaTask",
    },
})

