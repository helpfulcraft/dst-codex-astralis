
AddRoom("BGDirt", {
					colour={r=1.0,g=.8,b=.66,a=.50},
					value = WORLD_TILES.DIRT,
					tags = {"ExitPiece", "Chester_Eyebone","Astral_2"},
					contents =  {
					                distributepercent = .1,
					                distributeprefabs=
					                {
										rock1=1,
										rock2=1,
										rock_ice=.2,
					                },
					            }
					})
