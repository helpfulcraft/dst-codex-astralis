local VaseDecoration = Class(function(self, inst)
end)

return VaseDecoration