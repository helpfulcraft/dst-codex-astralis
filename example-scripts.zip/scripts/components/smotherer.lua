local Smotherer = Class(function(self, inst)
    self.inst = inst
end)


return Smotherer