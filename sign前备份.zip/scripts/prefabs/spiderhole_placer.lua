require "prefabutil"
return MakePlacer("spiderhole_placer", "spider_mound", "spider_mound", "full")