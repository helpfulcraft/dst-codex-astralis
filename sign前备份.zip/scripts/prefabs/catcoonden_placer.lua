require "prefabutil"
return MakePlacer("catcoonden_placer", "catcoon_den", "catcoon_den", "idle")