require "prefabutil"
return MakePlacer("beehive_placer", "beehive", "beehive", "cocoon_small")