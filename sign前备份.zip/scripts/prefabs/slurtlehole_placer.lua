require "prefabutil"
return MakePlacer("slurtlehole_placer", "slurtle_mound", "slurtle_mound", "idle")