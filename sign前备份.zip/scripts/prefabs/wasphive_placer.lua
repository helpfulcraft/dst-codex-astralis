require "prefabutil"
return MakePlacer("wasphive_placer", "wasphive", "wasphive", "cocoon_small")